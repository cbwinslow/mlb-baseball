format docs, not loaded
